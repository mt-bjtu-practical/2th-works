# 导入 Flask 库和其他必要的库
from flask import Flask, request, render_template, session, redirect, url_for
import mysql.connector

# 连接数据库
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="20281203",
    database="myorder"
)

# 创建 Flask 应用
app = Flask(__name__)
app.secret_key = 'my_secret_key'

'''
# 首页，展示所有数据
@app.route('/')
def index():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM orderr")
    data = cursor.fetchall()
    return render_template('index.html', data=data)
'''

# 创建游标对象
# cursor = db.cursor()


# 首页 - 登录页面
@app.route('/')
def index():
    return render_template('index.html')


# 处理登录表单提交
@app.route('/login_customer', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        customer_name = request.form['customer_name']
        seat_no = request.form['seat_no']
        cursor = db.cursor()
        query = "SELECT * FROM customer WHERE customer_name = '{}' AND seat_no = '{}'".format(customer_name, seat_no)
        cursor.execute(query)
        user = cursor.fetchone()
        if user:
            session['customer_name'] = user[0]       # 这里由1修改为0，显示username。如果是1，则为username=password，错误
            return redirect('/login_customer_success')
        else:
            return '登录失败，请检查用户名和座位号是否正确！'
    else:
        return render_template('login.html')


# 登陆成功
@app.route('/login_customer_success')
def login_success():
    if 'customer_name' in session:
        customer_name = session['customer_name']
        return render_template('login_success.html', customer_name=customer_name)
    else:
        return redirect('/login_customer')


# 注册页面
@app.route('/register', methods=['GET', 'POST'])
def register():
    # render_template('register.html')
    if request.method == 'POST':
        customer_name = request.form.get('customer_name')
        seat_no = request.form.get('seat_no')
        # username = request.form['username']
        # password = request.form['password']
        if not customer_name or not seat_no:
            return render_template('register.html', error_message='请填写完整的信息')

        cursor = db.cursor()
        query = "INSERT INTO customer (customer_name, seat_no) VALUES ('{}', '{}')".format(customer_name, seat_no)
        cursor.execute(query)
        db.commit()
        return redirect(url_for('register_success'))
    else:
        return render_template('register.html')


@app.route('/register_success')
def register_success():
    return render_template('register_success.html')


# 处理注销请求
@app.route('/logout')
def logout():
    # 从会话中删除用户信息
    session.pop('customer_name', None)
    return redirect('/')


# 查看菜单
@app.route('/menu')
def menu():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM menu")
    data = cursor.fetchall()
    return render_template('menu.html', data=data)


# 点餐
@app.route('/place_order', methods=['GET', 'POST'])
def place_order():
    if 'customer_name' in session:
        customer_name = session['customer_name']
        if request.method == 'POST':
            cuisine_no = request.form['cuisine_no']
            # 在此处进行数据库插入操作，将订单数据添加到 order 表中
            cursor = db.cursor()
            sql = "INSERT INTO orderr (cuisine_no, customer_no) VALUES (%s, %s)"
            values = (cuisine_no, customer_name)
            cursor.execute(sql, values)
            db.commit()
            return redirect(url_for('order_success'))
        else:
            # 查询menu表获取菜品信息
            cursor = db.cursor()
            query = "SELECT cuisine_no, cuisine_name FROM menu"
            cursor.execute(query)
            menus = cursor.fetchall()
            menu_dict = {menu[0]: menu[1] for menu in menus}  # 菜品号作为键，菜名作为值

            return render_template('place_order.html', menu_dict=menu_dict)
    else:
        return redirect('/login_customer_success')


# 点餐成功
@app.route('/order_success')
def order_success():
    if 'customer_name' in session:
        customer_name = session['customer_name']
        cursor = db.cursor()
        query = "SELECT * FROM order_price WHERE customer_no = '{}'".format(customer_name)
        cursor.execute(query)
        orders = cursor.fetchall()
        return render_template('order_success.html', orders=orders)
    else:
        return redirect('/login_customer_success')


# 查看现有订单
@app.route('/current_order')
def current():
    if 'customer_name' in session:
        customer_name = session['customer_name']
        cursor = db.cursor()
        query = "SELECT * FROM order_price WHERE customer_no = '{}'".format(customer_name)
        cursor.execute(query)
        orders = cursor.fetchall()
        return render_template('current_orders.html', orders=orders)
    else:
        return redirect('/login_customer_success')


# 员工登录
@app.route('/login_staff', methods=['GET', 'POST'])
def login_staff():
    if request.method == 'POST':
        waiter_no = request.form['waiter_no']
        waiter_name = request.form['waiter_name']
        password = request.form['password']
        cursor = db.cursor()
        query = "SELECT * FROM waiter WHERE waiter_no = '{}' AND waiter_name = '{}' AND password = '{}'".format(waiter_no, waiter_name, password)
        cursor.execute(query)
        user = cursor.fetchone()
        if user:
            session['waiter_name'] = user[0]       # 这里由1修改为0，显示username。如果是1，则为username=password，错误
            return redirect('/login_staff_success')
        else:
            return '登录失败，请检查用户名和座位号是否正确！'
    else:
        return render_template('login_staff.html')


# 员工登陆成功
@app.route('/login_staff_success')
def login_staff_success():
    if 'waiter_name' in session:
        waiter_name = session['waiter_name']
        return render_template('staff_success.html', waiter_name=waiter_name)
    else:
        return redirect('/login_staff')


# 展示所有数据
@app.route('/order')
def order():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM orderr")
    data = cursor.fetchall()
    return render_template('staff.html', data=data)


# 增加数据
@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        cursor = db.cursor()
        order_no = request.form['order_no']
        cuisine_no = request.form['cuisine_no']
        customer_no = request.form['customer_no']
        # sql = "INSERT INTO orderr (order_no, cuisine_no, customer_no) VALUES (%s, %s, %s)"
        sql = "call sp_insert_orderr(%s, %s, %s);"
        cursor.execute(sql, (order_no, cuisine_no, customer_no))
        db.commit()
        return render_template('add_success.html')
    else:
        return render_template('add.html')


# 修改数据
@app.route('/update/<string:order_no>', methods=['GET', 'POST'])
def update(order_no):
    if request.method == 'POST':
        cursor = db.cursor()
        order_no = request.form['order_no']
        cuisine_no = request.form['cuisine_no']
        customer_no = request.form['customer_no']
        sql = "UPDATE orderr SET customer_no=%s, cuisine_no=%s WHERE order_no=%s"
        # sql = "call sp_update_orderr_status(%s, %s, %s)"
        cursor.execute(sql, (customer_no, cuisine_no, order_no))
        db.commit()
        return render_template('update_success.html')
    else:
        cursor = db.cursor()
        cursor.execute("SELECT * FROM orderr WHERE order_no=%s", (order_no,))
        data = cursor.fetchone()
        return render_template('update.html', data=data)


# 删除数据
@app.route('/delete/<string:order_no>')
def delete(order_no):
    cursor = db.cursor()
    sql = "DELETE FROM orderr WHERE order_no=%s"
    # sql = "call sp_delete_order(%s)"
    cursor.execute(sql, (order_no,))
    db.commit()
    return render_template('delete_success.html')


# 查询数据
@app.route('/search', methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        cursor = db.cursor()
        order_no = request.form['order_no']
        sql = "SELECT * FROM orderr WHERE order_no = %s"
        # sql = "call sp_get_order_info(%s)"
        cursor.execute(sql, (order_no,))
        data = cursor.fetchall()
        return render_template('search_result.html', data=data)
    else:
        return render_template('search.html')


# 运行应用
if __name__ == '__main__':
    app.run(debug=True)
